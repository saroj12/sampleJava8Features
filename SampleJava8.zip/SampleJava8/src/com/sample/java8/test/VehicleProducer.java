package com.sample.java8.test;

/**
 * static and default method implementation example
 */
 public class VehicleProducer implements Vehicle {

     public void display(){
         System.out.println("The value of the display is::");
     }
     public int add(int first,int second){
         System.out.println("The value of sum is ::");
         int sum=0;
         sum=first+second;
            return sum;
     }
       public static void main(String args[]){

        VehicleProducer producerData = new VehicleProducer();
        String producer=Vehicle.producer();
        System.out.println("*******************producer**********:::"+producer);
           int sum2=producerData.add(12,13);
           System.out.println("*******************sum of two no is::**********:::"+sum2);

    }
}
