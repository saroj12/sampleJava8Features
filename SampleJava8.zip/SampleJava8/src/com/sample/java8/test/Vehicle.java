package com.sample.java8.test;

public interface Vehicle {

    void display();
    public int  add(int a,int b);
    static String producer(){
        return "N&F vehicles";
    }
}
